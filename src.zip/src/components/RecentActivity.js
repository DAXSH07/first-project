import React from 'react';

function RecentActivity() {
  return (
    <div className="widget recent-activity">
      <h3>Recent Activity/Notification</h3>
      <p>No recent activity</p>
    </div>
  );
}

export default RecentActivity;
