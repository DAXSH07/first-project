import React from 'react';

function Analytics() {
  return (
    <div className="widget analytics">
      <h3>Analytics/Reports</h3>
      {/* Add report details here */}
    </div>
  );
}

export default Analytics;
